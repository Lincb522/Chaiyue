# 柴阅阅读主题

从 examples/starter-web 或 examples/eink 开始。修改 theme.json 中的名称与标识，再编辑同目录下的 HTML、CSS 和 JavaScript。

在解压后的目录执行：

```sh
python3 tools/preview.py examples/starter-web
python3 tools/pack.py examples/starter-web
```

在 iPhone 上用柴阅打开生成的 .chaiyuetheme 文件。

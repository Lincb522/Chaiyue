var THEME = {
  "id": "starter-web",
  "label": "云边书签",
  "characters": [],
  "decorations": [
    {
      "src": "star.png",
      "name": "星星"
    },
    {
      "src": "moon.png",
      "name": "月亮"
    },
    {
      "src": "book.png",
      "name": "书本"
    }
  ],
  "heroCaption": "故事正要开始",
  "endLabel": "已收藏这一章",
  "quiet": false
};
/*
 * 柴阅 · 示例主题重制版 / 网页模式共用脚本
 * 将本文件接在 var THEME = {...}; 之后即可使用。
 * 素材一律只写文件名；阅读器导入时会把 assets/ 平铺。
 * 章头装饰只在分页前添加；正文、段落偏移与运行时布局均保持原样。
 */
(function () {
  'use strict';

  var settings = typeof THEME === 'object' && THEME ? THEME : {};
  var asAssets = function (items) {
    return Array.isArray(items) ? items.filter(function (item) {
      return item && typeof item.src === 'string' && item.src.length > 0;
    }) : [];
  };
  var characters = asAssets(settings.characters);
  var decorations = asAssets(settings.decorations);
  var portraits = characters.length ? characters : decorations;
  var decor = document.getElementById('decor');
  var corner = decor && decor.querySelector('.corner-button');
  var cornerArt = corner && corner.querySelector('.corner-art');
  var edgeArt = decor && decor.querySelector('.edge-art');
  var endLabel = decor && decor.querySelector('.end-badge .end-label');
  var lastChapter = null;
  var selectedPortrait = 0;

  function chapterNumber(value) {
    var number = Number(value);
    return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0;
  }

  function pick(items, index) {
    return items.length ? items[index % items.length] : null;
  }

  function setImage(img, asset) {
    if (!img) return;
    if (!asset) {
      img.hidden = true;
      return;
    }
    if (img.getAttribute('src') !== asset.src) img.setAttribute('src', asset.src);
    img.hidden = false;
    img.alt = '';
    img.draggable = false;
    img.setAttribute('data-art-name', asset.name || '');
  }

  function updateCorner() {
    var portrait = pick(portraits, selectedPortrait);
    setImage(cornerArt, portrait);
    if (!corner) return;
    corner.hidden = !portrait;
    if (portrait) {
      corner.setAttribute('aria-label', '切换贴纸：' + (portrait.name || settings.label || '阅读伙伴'));
      corner.setAttribute('title', portrait.name || '切换贴纸');
    }
  }

  // 页眉留下当前书名／章名；页脚左侧留给运行时的可拖动页码条。
  window.header = function (ctx) {
    ctx = ctx || {};
    return { left: (Number(ctx.page) === 1 ? ctx.book : ctx.chapter) || ctx.book || '' };
  };

  window.footer = function (ctx) {
    ctx = ctx || {};
    var pages = Math.max(1, chapterNumber(ctx.pages));
    var page = Math.min(pages, Math.max(1, chapterNumber(ctx.page)));
    return { right: page + ' / ' + pages };
  };

  window.chapterReady = function (el, info) {
    if (!el || !portraits.length) return;
    var head = el.querySelector('.chap-head');
    if (!head || head.querySelector('.theme-heading-art')) return;
    var portrait = pick(portraits, chapterNumber(info && info.index));
    var art = document.createElement('div');
    art.className = 'theme-heading-art';
    art.setAttribute('aria-hidden', 'true');
    var img = document.createElement('img');
    img.className = 'theme-hero';
    // 显式保留图像尺寸；CSS 可缩放这个固定盒子，图片解码后不会挤动正文。
    img.width = 96;
    img.height = 96;
    img.decoding = 'async';
    setImage(img, portrait);
    art.appendChild(img);
    var caption = document.createElement('span');
    caption.className = 'theme-heading-caption';
    caption.textContent = settings.heroCaption || '';
    art.appendChild(caption);
    head.appendChild(art);
  };

  if (endLabel) endLabel.textContent = settings.endLabel || '本章读完';

  document.addEventListener('readerpage', function (event) {
    var ctx = event.detail || {};
    var index = chapterNumber(ctx.chapterIndex);
    var chapterKey = String(ctx.book || '') + '\u0000' + index;
    // 翻页、拖动和每 30 秒的时钟刷新都不更换贴纸；仅换章时更新。
    if (chapterKey === lastChapter) return;
    lastChapter = chapterKey;
    selectedPortrait = portraits.length ? index % portraits.length : 0;
    updateCorner();
    setImage(edgeArt, pick(decorations, index));
    if (corner) corner.classList.remove('is-reacting');
  });

  if (corner) {
    corner.setAttribute('data-tap', '');
    if (corner.tagName.toLowerCase() === 'button') corner.setAttribute('type', 'button');
    corner.addEventListener('click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (!portraits.length) return;
      selectedPortrait = (selectedPortrait + 1) % portraits.length;
      updateCorner();
      var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!settings.quiet && !reduced) corner.classList.add('is-reacting');
    });
    corner.addEventListener('animationend', function () {
      corner.classList.remove('is-reacting');
    });
  }
})();

/* This theme's independent composition. */
(function () {
  'use strict';
  var page = document.getElementById('page');
  var decor = document.getElementById('decor');
  if (page) page.dataset.layout = 'cloud-bookmark';
  if (decor) {
    var spine = document.createElement('div');
    spine.className = 'cloud-spine'; spine.setAttribute('aria-hidden', 'true');
    decor.appendChild(spine);
    var clouds = document.createElement('div');
    clouds.className = 'cloud-bed'; clouds.setAttribute('aria-hidden', 'true');
    decor.insertBefore(clouds, decor.firstChild);
    var moon = decor.querySelector('.footer-art');
    if (moon) moon.src = 'moon.png';
  }
  window.header = function (ctx) {
    return { left: ctx.page === 1 ? ctx.book : ctx.chapter };
  };
  window.footer = function (ctx) {
    return { left: '云边书签', center: ctx.page + ' / ' + ctx.pages, right: Math.round(ctx.percent || 0) + '%' };
  };
})();

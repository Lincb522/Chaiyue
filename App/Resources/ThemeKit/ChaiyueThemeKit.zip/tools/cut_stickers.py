#!/usr/bin/env python3
"""把「纯色背景上排成网格的贴纸」切成一张张透明 PNG（只依赖 Pillow）。

用法：
    python3 tools/cut_stickers.py 贴纸图.jpg 列数 行数 名字1,名字2,... [输出目录] [最长边]
例：
    python3 tools/cut_stickers.py sheet.jpg 3 2 cat,coffee,star,cloud,blossom,book out 300

做法：取左上角的颜色作为背景色，只去掉「和格子边缘连通」且颜色接近背景的区域，
所以贴纸内部和背景同色的部分（比如红色草莓、品红花瓣）不会被误删；
每格只保留中间那张贴纸，相邻贴纸伸过来的边角会被裁掉。
背景最好是贴纸里没有的颜色（如品红 #FF00FF 或纯绿），贴纸带白色模切边效果最好。
"""
import pathlib
import sys

from PIL import Image, ImageChops, ImageDraw, ImageFilter

THRESHOLD = 70      # 与背景色的差值小于它就算背景
HOLE_THRESHOLD = 36  # 不与边缘连通的区域，差值小于它也算背景


def cut(sheet: str, cols: int, rows: int, names: list[str], out_dir: pathlib.Path, longest: int):
    im = Image.open(sheet).convert("RGB")
    w, h = im.size
    bg = im.getpixel((6, 6))
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, name in enumerate(names):
        c, r = i % cols, i // cols
        # 每格向外多取 12%，贴纸稍微越过格线也不会被切掉
        mx, my = w // cols * 12 // 100, h // rows * 12 // 100
        cell = im.crop((max(0, c * w // cols - mx), max(0, r * h // rows - my),
                        min(w, (c + 1) * w // cols + mx), min(h, (r + 1) * h // rows + my)))
        cw, ch = cell.size
        diff = ImageChops.difference(cell, Image.new("RGB", cell.size, bg))
        a, b, cc = diff.split()
        d = ImageChops.lighter(ImageChops.lighter(a, b), cc)
        mask = d.point(lambda v: 0 if v < THRESHOLD else 255)
        # 从格子四边向内灌水，标出真正的背景
        for x, y in [(0, 0), (cw - 1, 0), (0, ch - 1), (cw - 1, ch - 1),
                     (cw // 2, 0), (cw // 2, ch - 1), (0, ch // 2), (cw - 1, ch // 2)]:
            if mask.getpixel((x, y)) == 0:
                ImageDraw.floodfill(mask, (x, y), 128)
        fg = mask.point(lambda v: 0 if v == 128 else 255)
        # 被贴纸围住的背景（比如救生圈中间的洞）：和背景色几乎一样的才去掉
        holes = d.point(lambda v: 0 if v < HOLE_THRESHOLD else 255)
        fg = ImageChops.multiply(fg, holes)
        # 从中心向外找第一个前景点，灌水得到中间那张贴纸
        seed = None
        for step in range(min(cw, ch) // 2):
            for dx, dy in [(step, 0), (-step, 0), (0, step), (0, -step)]:
                p = (cw // 2 + dx, ch // 2 + dy)
                if fg.getpixel(p) == 255:
                    seed = p
                    break
            if seed:
                break
        if not seed:
            print(f"{name}：格子里没找到贴纸，跳过")
            continue
        comp = fg.copy()
        ImageDraw.floodfill(comp, seed, 200)
        # 只保留和中间贴纸连在一起的像素，相邻贴纸伸进来的边角不要
        alpha = comp.point(lambda v: 255 if v == 200 else 0)
        box = alpha.getbbox()
        # 收一像素再羽化，去掉边缘的背景色残留
        alpha = alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(0.8))
        out = cell.convert("RGBA")
        out.putalpha(alpha)
        out = out.crop(box)
        if max(out.size) > longest:
            s = longest / max(out.size)
            out = out.resize((round(out.width * s), round(out.height * s)), Image.LANCZOS)
        path = out_dir / f"{name}.png"
        out.save(path, optimize=True)
        print(f"{path}  {out.size[0]}×{out.size[1]}")


if __name__ == "__main__":
    if len(sys.argv) < 5:
        print(__doc__)
        sys.exit(1)
    cut(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4].split(","),
        pathlib.Path(sys.argv[5] if len(sys.argv) > 5 else "."), int(sys.argv[6]) if len(sys.argv) > 6 else 300)

#!/usr/bin/env python3
"""把主题文件夹打包成 .chaiyuetheme（就是 zip），可以 AirDrop / 文件 App 导入柴阅。

用法：
    python3 tools/pack.py examples/sticker-journal [输出目录]
    python3 tools/pack.py --all          # 打包 examples 下所有示例到 dist/themes/

包内结构：theme.json、style.css、script.js、page.html、assets/素材。以 _ 或 . 开头的文件不打包。
"""
import json
import pathlib
import sys
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
EXAMPLES = HERE.parent / "examples"
# 源码仓库里输出到仓库根的 dist/themes/，开发包里输出到包内的 dist/
REPO = HERE.parents[2] if len(HERE.parents) > 2 else None
DIST = REPO / "dist/themes" if REPO and (REPO / "App").exists() else HERE.parent / "dist"
KNOWN = ["theme.json", "style.css", "script.js", "page.html"]


def pack(folder: pathlib.Path, out_dir: pathlib.Path) -> pathlib.Path:
    manifest = json.loads((folder / "theme.json").read_text(encoding="utf-8"))
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{folder.name}.chaiyuetheme"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name in KNOWN:
            if (folder / name).exists():
                z.write(folder / name, name)
        assets = folder / "assets"
        if assets.is_dir():
            for f in sorted(assets.iterdir()):
                if f.is_file() and not f.name.startswith((".", "_")):
                    z.write(f, f"assets/{f.name}")
    print(f"{manifest['name']}（{manifest['mode']}）→ {out}  {out.stat().st_size // 1024} KB")
    return out


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    if sys.argv[1] == "--all":
        for folder in sorted(EXAMPLES.iterdir()):
            if (folder / "theme.json").exists():
                pack(folder, DIST)
    else:
        pack(pathlib.Path(sys.argv[1]).resolve(), pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else DIST)

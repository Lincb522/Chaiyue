#!/usr/bin/env python3
"""柴阅主题 · 电脑端预览

用法：
    python3 tools/preview.py examples/sticker-journal
    # 然后在主题目录下起一个静态服务器：
    cd examples/sticker-journal && python3 -m http.server 8800
    # 浏览器打开 http://localhost:8800/_preview.html ，开发者工具切到 iPhone 尺寸（393×852）

页面里用的是 App 内同一份网页运行时（开发包里是 tools/runtime/，源码仓库里直接从 WebReaderRuntime.swift 读），
键盘 ←/→ 或点屏幕左右两侧翻页，点中间切换深浅色说明，翻过章尾会进入下一章。
地址参数：?size=19 字号，&mode=scroll 滚动模式，&chapter=2 从第几章开始，&page=3 跳到第几页。
"""
import json
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
# 开发包：运行时导出在 tools/runtime/；源码仓库：从 App 源码读
EXPORTED = HERE / "runtime"
RUNTIME = HERE.parents[2] / "App/Sources/Reader/WebReaderRuntime.swift" if len(HERE.parents) > 2 else None


def swift_block(source: str, start: str, end: str) -> str:
    i = source.index(start) + len(start)
    j = source.index(end, i)
    lines = source[i:j].split("\n")
    return "\n".join(l[4:] if l.startswith("    ") else l for l in lines)


def runtime():
    if RUNTIME is None or not RUNTIME.exists():
        read = lambda name: (EXPORTED / name).read_text(encoding="utf-8")
        return read("base.css"), read("runtime.js"), read("typography.css")
    src = RUNTIME.read_text(encoding="utf-8")
    css = swift_block(src, 'static let baseCSS = """\n', '\n    """')
    js = swift_block(src, 'static let runtimeJS = #"""\n', '\n    """#')
    lock = swift_block(src, 'static let typographyCSS = """\n', '\n    """')
    return css, js, lock


# 示例正文：故意放进「猫、咖啡、雨、月、花、书、蛋糕、星、云、喜欢」等关键词，方便看关键词贴纸
CHAPTERS = [
    ("第一章", "雨天的猫咖啡馆", [
        "雨是从午后开始下的，细细密密，把整条街都洗成了淡淡的灰色。她收起伞，推开那扇挂着铃铛的木门，铃声叮叮当当地响了好一阵。",
        "店里很暖，空气里飘着烤面包和咖啡豆混在一起的香味。靠窗的位置空着，玻璃上爬满了细小的水珠，外面的行人都成了模糊的影子。",
        "“还是老样子？”老板从柜台后面探出头来，手里还拿着一块没擦完的杯子。",
        "她点点头，把湿了一角的书放在桌上。这本书她已经读了三遍，书页的边缘都起了毛，可每次读到最后一章，还是会忍不住停下来发一会儿呆。",
        "一只橘色的猫从书架顶上跳下来，轻巧地落在她对面的椅子上，蜷成一团，尾巴一下一下地扫着椅背。它眯着眼睛看她，好像在说：你又来了。",
        "她笑了，伸手挠了挠它的下巴。猫发出呼噜呼噜的声音，像一台小小的、毛茸茸的发动机。",
        "咖啡端上来的时候，杯沿上还浮着一层细腻的奶泡，被拉成了一片小小的叶子。她用勺子轻轻碰了一下，叶子晃了晃，又慢慢地合拢。",
        "窗外的雨渐渐小了，屋檐滴下来的水在石阶上敲出很轻的节奏。她翻开书，从夹着书签的那一页继续往下读。",
        "故事里的主人公正站在一座陌生城市的车站，手里攥着一张写着地址的纸条。纸条被汗水浸得有点软，字迹却还清清楚楚。",
        "她读得很慢，一句一句地读，像是怕把这个下午读完。偶尔抬头，看见猫已经睡着了，肚子随着呼吸一起一伏。",
        "窗外的小河上漂过一条小船，船头蹲着一只白色的小狗，冲着岸边的海鸥汪汪叫。撑船的老人戴着一顶旧草帽，慢悠悠地摇着橹。",
        "隔壁桌的小孩趴在桌上画画，蜡笔散了一桌子，红的黄的蓝的。他画了一个大大的太阳，又在太阳下面画了一片竹林和一池荷花。",
        "“我要去很远很远的地方。”小孩举着画说，“坐火箭去宇宙，看别的星球上有没有鱼。”他妈妈笑着递给他一块饼干。",
        "柜台那边传来磨豆子的声音，咔啦咔啦的，和雨声混在一起，竟然一点也不吵。她忽然觉得，这样的下午，大概就是她最喜欢的样子。",
        "不知过了多久，雨停了。云层裂开一道缝，一束光斜斜地照进来，落在桌面上，落在书页上，也落在猫的耳朵尖上。",
        "老板端来一小块蛋糕，说是新试做的，请她尝尝。奶油上点缀着几颗草莓，甜而不腻，带着一点点酸。",
        "“好吃。”她说。老板满意地点点头，又回到柜台后面擦他的杯子去了。",
        "她把最后一口咖啡喝完，合上书，看了看窗外。街道上的水洼映着刚放晴的天空，像一块块碎掉的蓝玻璃。",
        "猫醒了，伸了一个长长的懒腰，跳下椅子，慢悠悠地走回书架那边去了。走到一半还回头看了她一眼，好像在说：明天见。",
        "她背上包，推门出去。铃铛又叮叮当当地响了起来，和来的时候一模一样。",
        "空气里还带着雨后的潮湿，路边的花坛里，几朵不知名的小花被雨打得低着头，花瓣上挂着亮晶晶的水珠。",
        "她沿着街慢慢地走，脚步很轻。今天什么特别的事也没有发生，可她心里满满的，像是被什么温暖的东西装满了。",
        "回到家，她把书放回书架，在日记本上写下一行字：今天下雨，喝了咖啡，见到了猫。",
    ]),
    ("第二章", "月亮和星星的信", [
        "夜里起了风，窗帘被吹得一鼓一鼓的。她睡不着，干脆披上外套，坐到阳台上看月亮。",
        "月亮很圆，亮得有点不真实，像是有人在天上挖了一个洞，把另一个世界的光漏了进来。",
        "楼下的路灯一盏一盏地亮着，远处偶尔有车开过，车灯在墙上划出一道很长的光，又很快消失了。",
        "她想起小时候，外婆总说，天上的每一颗星星都是一封没寄出去的信。那时候她信以为真，常常趴在窗台上数星星，想知道哪一封是写给自己的。",
        "后来长大了，知道星星离地球很远很远，远到它们的光要走上好几百年才能到达这里。可她还是愿意相信外婆的话。",
        "她从口袋里摸出一张便签纸，借着月光写了几个字，又折成一只小小的纸鹤，放在阳台的栏杆上。",
        "风吹过来，纸鹤晃了晃，没有掉下去。她看着它，忽然觉得心里很安静。",
        "隔壁的窗户也亮着灯，隐约能听见有人在弹琴，弹的是一首很老的曲子，断断续续的，像是在一边弹一边回忆。",
        "她靠在椅背上，闭上眼睛听。琴声和风声缠在一起，飘得很远很远。",
        "不知过了多久，琴声停了，隔壁的灯也熄了。夜更深了，月亮慢慢地移到了楼的另一边。",
        "她站起来，把纸鹤收进口袋，回到屋里。床头的小台灯还亮着，照着摊开的书，书页上有一行她用铅笔划过的句子。",
        "“所有的告别，都是为了下一次更好的相遇。”",
        "她把灯关了，躺下来，看着天花板上淡淡的月光。这一次，她很快就睡着了。",
        "梦里，她回到了外婆家的院子，院子里开满了花，外婆坐在藤椅上，笑着朝她招手。",
        "“你收到信了吗？”外婆问。",
        "她点点头，又摇摇头。外婆笑了，指了指天上，说：“不急，慢慢来，总会收到的。”",
    ]),
]


def chapter_html(no, title, paragraphs):
    esc = lambda s: s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    out = [f'<header class="chap-head"><div class="chap-no">{esc(no)}</div><h1 class="chap-title">{esc(title)}</h1></header>']
    offset = 0
    for i, text in enumerate(paragraphs):
        out.append(f'<p data-i="{i}" data-o="{offset}" data-len="{len(text)}">{esc(text)}</p>')
        offset += len(text) + 1
    return "".join(out), offset


def build(theme_dir: pathlib.Path):
    css_base, js_runtime, css_lock = runtime()
    read = lambda name: (theme_dir / name).read_text(encoding="utf-8") if (theme_dir / name).exists() else ""
    css = re.sub(r"</style", r"<\\/style", read("style.css"), flags=re.I)
    js = re.sub(r"</script", r"<\\/script", read("script.js"), flags=re.I)
    html = read("page.html")
    chapters = []
    for idx, (no, title, paras) in enumerate(CHAPTERS):
        body, length = chapter_html(no, title, paras)
        chapters.append({"key": f"c{idx}", "html": body, "meta": {"index": idx, "title": f"{no} {title}", "book": "雨天的猫咖啡馆",
                                                "author": "柴阅示例", "chapterCount": len(CHAPTERS), "battery": 72,
                                                "hasPrev": idx > 0, "hasNext": idx < len(CHAPTERS) - 1, "length": length}})
    page = f"""<!doctype html>
<html lang="zh-Hans">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<base href="assets/">
<style id="font-faces"></style>
<style>{css_base}</style>
<style id="theme-style">{css}</style>
<style>{css_lock}</style>
</head>
<body>
<div class="page" id="page">
  <div id="decor">{html}</div>
  <div class="header" id="header"><span class="left"></span><span class="center"></span><span class="right"></span></div>
  <div id="viewport"><div id="track"><div id="snaps"></div></div></div>
  <div class="footer" id="footer"><span class="left"></span><span class="center"></span><span class="right"></span></div>
</div>
<script>
// 模拟 App：接住运行时回传的消息
var CHAPTERS = {json.dumps(chapters, ensure_ascii=False)};
var current = 0;
function push(force, offset) {{
  var list = CHAPTERS.filter(function (c) {{ return Math.abs(c.meta.index - current) <= 1; }});
  reader.setChapters(list, {{ chapter: current, offset: offset, force: force }});
}}
window.webkit = {{ messageHandlers: {{ reader: {{ postMessage: function (m) {{
  if (m.type === 'error' || m.type === 'log') console.info('[主题]', m.message);
  // 滑进相邻章：与 App 一样把章节窗口挪过去
  if (m.type === 'position' && m.chapter !== current) {{ current = m.chapter; push(false, 0); }}
  if (m.type === 'edge') {{
    var next = current + (m.dir === 'next' ? 1 : -1);
    if (next < 0 || next >= CHAPTERS.length) return;
    current = next;
    push(true, m.dir === 'next' ? 0 : 1 << 30);
  }}
}} }} }} }};
</script>
<script>{js_runtime}</script>
<script>
{js}
</script>
<script>
window.reader.__boot();
(function () {{
  var q = new URLSearchParams(location.search);
  var size = q.get('size') || '19';
  var dark = matchMedia('(prefers-color-scheme: dark)').matches;
  reader.configure({{ mode: q.get('mode') || 'page', safeTop: 47, safeBottom: 34, vars: {{
    '--reader-font-size': size + 'px', '--reader-font': '-apple-system, "PingFang SC", sans-serif',
    '--reader-line-height': '1.9', '--reader-para': '.5em', '--reader-indent': '2em', '--reader-kern': '0em',
    '--reader-align': 'justify', '--reader-paper': dark ? 'rgb(14,14,15)' : 'rgb(242,235,221)',
    '--reader-ink': dark ? 'rgb(142,138,132)' : 'rgb(44,39,33)',
    '--reader-secondary': dark ? 'rgba(142,138,132,.45)' : 'rgba(44,39,33,.45)',
    '--reader-mark': 'rgba(255,213,8,.3)' }} }});
  current = Math.max(0, Math.min(CHAPTERS.length - 1, (+q.get('chapter') || 1) - 1));
  push(true, 0);
  if (q.get('page')) setTimeout(function () {{ reader.goPage(+q.get('page') - 1); }}, 200);
  // 电脑上没有触摸：用键盘和鼠标翻页
  document.addEventListener('keydown', function (e) {{
    if (e.key === 'ArrowRight' || e.key === ' ') reader.turn(true);
    if (e.key === 'ArrowLeft') reader.turn(false);
  }});
  if (!('ontouchstart' in window)) document.addEventListener('click', function (e) {{
    if (e.target.closest('[data-tap], a, button')) return;
    if (e.clientX > innerWidth * 2 / 3) reader.turn(true);
    else if (e.clientX < innerWidth / 3) reader.turn(false);
  }});
}})();
</script>
</body>
</html>
"""
    out = theme_dir / "_preview.html"
    out.write_text(page, encoding="utf-8")
    print("已生成", out)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    build(pathlib.Path(sys.argv[1]).resolve())

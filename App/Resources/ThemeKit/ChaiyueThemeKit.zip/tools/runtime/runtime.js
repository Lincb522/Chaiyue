(function () {
  'use strict';
  const post = (type, data) => {
    try { webkit.messageHandlers.reader.postMessage(Object.assign({ type: type }, data || {})); } catch (e) {}
  };
  window.__reportError = e => post('error', { message: String(e && e.message || e) + (e && e.line ? '（第 ' + e.line + ' 行）' : '') });
  window.addEventListener('error', e => post('error', { message: (e.message || '脚本错误') + (e.lineno ? '（第 ' + e.lineno + ' 行）' : '') }));
  console.log = function () { post('log', { message: Array.prototype.map.call(arguments, String).join(' ') }); };
  console.error = console.warn = console.log;

  const R = window.reader = {};
  const $ = id => document.getElementById(id);
  /// 停在章末的稳定偏移（原生按「超过章长」处理）
  const END = 1 << 30;
  let page, viewport, track, snaps, headerEl, footerEl, fontStyle, decorEl;
  let cfg = { mode: 'page', turn: 'slide', safeTop: 47, safeBottom: 34, menu: false, tapBoth: false, interactive: true, vars: {} };
  /// 仿真翻页截下一页时为 true：滚动只为截图，不上报阅读位置
  let quiet = false;
  /// 按章序排列：{ index, key, meta, el, start（首页在轨道上的页号）, count, fromEnd（占位页是从后一章翻回来的） }
  let chapters = [];
  let cur = null;
  let W = 1, H = 1, padL = 0, padR = 0, textTop = 0, textBottom = 0, total = 1, shown = -1, shownCh = null;
  /// 手指按着或滚动没停时不动排版，新内容与重排排队到停稳后
  let touching = false, scrolling = false, scrollTimer = 0, queued = null, dirty = false;
  let reportTimer = 0;
  /// 定位目标那一章还是占位页时先记住偏移，等正文到了再定位过去
  let pendingFocus = null;

  const hook = name => typeof window[name] === 'function' ? window[name] : null;
  const call = (fn, args) => { try { return fn.apply(null, args); } catch (e) { window.__reportError(e); return null; } };
  const paged = () => cfg.mode !== 'scroll';
  const busy = () => touching || scrolling;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  // MARK: 布局

  function measure() {
    const cs = getComputedStyle(page);
    const num = v => parseFloat(v) || 0;
    const top = Math.max(cfg.safeTop, 24), bottom = Math.max(cfg.safeBottom, 12);
    padL = num(cs.paddingLeft);
    padR = num(cs.paddingRight);
    headerEl.style.top = top + 'px';
    footerEl.style.bottom = (bottom + 1) + 'px';
    [headerEl, footerEl].forEach(el => { el.style.left = padL + 'px'; el.style.right = padR + 'px'; });
    textTop = top + num(cs.paddingTop);
    textBottom = bottom + 15 + num(cs.paddingBottom) - 4;
    page.style.setProperty('--safe-top', top + 'px');
    page.style.setProperty('--safe-bottom', bottom + 'px');
    page.style.setProperty('--text-top', textTop + 'px');
    page.style.setProperty('--text-bottom', textBottom + 'px');
    W = Math.max(1, Math.round(page.clientWidth));
    H = Math.max(1, Math.round(page.clientHeight - textTop - textBottom));
    document.documentElement.style.setProperty('--reader-page-height', H + 'px');
    page.classList.toggle('paged', paged());
    page.classList.toggle('scroll-mode', !paged());
    page.classList.toggle('static', !cfg.interactive);
    page.classList.toggle('curl', paged() && cfg.turn === 'curl');
    viewport.style.top = paged() ? '0' : textTop + 'px';
    viewport.style.bottom = paged() ? '0' : textBottom + 'px';
  }

  function layout() {
    measure();
    if (!paged()) {
      chapters.forEach(ch => {
        ch.el.style.cssText = ch === cur ? 'position:relative;padding:0 ' + padR + 'px 0 ' + padL + 'px' : 'display:none';
        ch.start = 0;
        ch.count = 1;
      });
      total = 1;
      track.style.width = '';
      snaps.innerHTML = '';
      placeScrub();
      return;
    }
    const gap = padL + padR, colW = Math.max(1, W - gap);
    let start = 0;
    chapters.forEach(ch => {
      ch.el.style.cssText = 'position:absolute;top:' + textTop + 'px;left:' + (start * W + padL) + 'px;width:' + colW
        + 'px;height:' + H + 'px;column-width:' + colW + 'px;column-gap:' + gap + 'px;column-fill:auto';
      ch.start = start;
      ch.count = ch.meta.placeholder ? 1 : Math.max(1, Math.round((ch.el.scrollWidth + gap) / W));
      start += ch.count;
    });
    total = Math.max(1, start);
    track.style.width = total * W + 'px';
    let marks = '';
    for (let i = 0; i < total; i++) marks += '<i style="left:' + i * W + 'px"></i>';
    snaps.innerHTML = marks;
    placeScrub();
  }

  const pageNow = () => paged() ? clamp(Math.round(viewport.scrollLeft / W), 0, total - 1) : 0;

  function locate(g) {
    for (const ch of chapters) if (g < ch.start + ch.count) return ch;
    return chapters[chapters.length - 1] || null;
  }

  function setCurrent(ch) {
    if (!ch || ch === cur) return;
    if (cur && ch.meta.placeholder) ch.fromEnd = ch.index < cur.index;
    if (pendingFocus && pendingFocus.chapter !== ch.index) pendingFocus = null;
    if (cur) cur.el.removeAttribute('id');
    cur = ch;
    ch.el.id = 'chapter';
  }

  function scrollToPage(g, smooth) {
    g = clamp(g, 0, total - 1);
    if (smooth) {
      viewport.scrollTo({ left: g * W, behavior: 'smooth' });
    } else {
      viewport.scrollLeft = g * W;
      setCurrent(locate(g));
    }
  }

  // MARK: 偏移

  const blocks = ch => ch.el.querySelectorAll('[data-o]');

  /// 稳定偏移 → 文本里的点 {node, offset}
  function point(ch, offset) {
    let target = null;
    for (const el of blocks(ch)) { if (+el.dataset.o <= offset) target = el; else break; }
    if (!target) return null;
    let remain = Math.min(offset - +target.dataset.o, +target.dataset.len);
    const walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let node, last = null;
    while ((node = walker.nextNode())) {
      if (node.nodeType === 1) {
        if (node.classList.contains('comment')) break;
        if (node.tagName === 'IMG') { if (remain < 1) return { node: node, img: true }; remain -= 1; }
        continue;
      }
      if (node.parentElement.closest('.comment')) break;
      last = node;
      if (remain < node.length) return { node: node, offset: remain };
      remain -= node.length;
    }
    if (last) return { node: last, offset: last.length };
    return { node: target, el: true };
  }

  function rectOf(ch, offset) {
    const p = point(ch, offset);
    if (!p) return null;
    if (p.img || p.el) return p.node.getClientRects()[0] || p.node.getBoundingClientRect();
    const r = document.createRange();
    r.setStart(p.node, p.offset);
    r.setEnd(p.node, Math.min(p.node.length, p.offset + 1));
    const rects = r.getClientRects();
    return rects[0] || r.getBoundingClientRect();
  }

  /// 文本里的点 → 稳定偏移
  function offsetAt(node, inner) {
    const el = (node.nodeType === 1 ? node : node.parentElement).closest('[data-o]');
    if (!el) return null;
    const r = document.createRange();
    r.setStart(el, 0);
    try { r.setEnd(node, inner); } catch (e) { return +el.dataset.o; }
    const images = r.cloneContents().querySelectorAll('img.inline').length;
    return +el.dataset.o + Math.min(+el.dataset.len, r.toString().length + images);
  }

  function caret(ch, cx, cy) {
    const range = document.caretRangeFromPoint(cx, cy);
    if (!range || !ch.el.contains(range.startContainer)) return null;
    return offsetAt(range.startContainer, range.startOffset);
  }

  /// 正文区在屏幕上的范围
  function textRect() {
    if (!paged()) return viewport.getBoundingClientRect();
    return { left: padL, right: W - padR, top: textTop, bottom: textTop + H };
  }

  /// 屏幕上能看到的稳定偏移范围
  function visibleRange(ch) {
    if (ch.meta.placeholder) return ch.fromEnd ? [END, END + 1] : [0, 1];
    const v = textRect();
    let first = null, lastEl = null;
    for (const el of blocks(ch)) {
      const rects = el.getClientRects();
      for (const r of rects) {
        if (r.right > v.left + 1 && r.left < v.right - 1 && r.bottom > v.top + 1 && r.top < v.bottom - 1) {
          if (!first) first = { el: el, r: r };
          lastEl = { el: el, r: r };
        }
      }
      if (first && rects.length && (paged() ? rects[0].left > v.right : rects[0].top > v.bottom)) break;
    }
    if (!first) return [0, 0];
    const fr = first.r;
    let start = caret(ch, Math.max(fr.left, v.left) + 2, Math.max(fr.top, v.top) + 6);
    if (start == null || start < +first.el.dataset.o) start = +first.el.dataset.o;
    const lr = lastEl.r;
    let end = caret(ch, Math.min(lr.right, v.right) - 2, Math.min(lr.bottom, v.bottom) - 6);
    if (end == null || end < start) end = +lastEl.el.dataset.o + +lastEl.el.dataset.len;
    return [start, Math.max(start + 1, end)];
  }

  /// 翻页模式：偏移在本章第几页；滚动模式：偏移离顶部的距离
  function pageOf(ch, offset) {
    const r = rectOf(ch, offset);
    if (!r) return 0;
    if (!paged()) return r.top - viewport.getBoundingClientRect().top + viewport.scrollTop;
    const g = Math.floor((r.left + viewport.scrollLeft - padL + 1) / W);
    return clamp(g - ch.start, 0, ch.count - 1);
  }

  function goTo(ch, offset) {
    if (!ch) return;
    const length = ch.meta.length || 0;
    const atEnd = ch.meta.placeholder ? false : offset >= length && length > 0;
    if (!paged()) {
      if (ch.meta.placeholder || offset <= 0) viewport.scrollTop = 0;
      else if (atEnd) viewport.scrollTop = viewport.scrollHeight;
      else viewport.scrollTop = Math.max(0, pageOf(ch, offset) - 4);
      return;
    }
    let local = 0;
    if (atEnd) local = ch.count - 1;
    else if (!ch.meta.placeholder && offset > 0) local = pageOf(ch, offset);
    scrollToPage(ch.start + local, false);
  }

  /// 当前看到的位置，重排后据此回到原处
  function anchor() {
    if (!cur) return null;
    return { chapter: cur.index, offset: visibleRange(cur)[0] };
  }

  function rebuild(a) {
    const ch = (a && chapters.find(c => c.index === a.chapter)) || (chapters.includes(cur) ? cur : null) || chapters[0] || null;
    if (cur && cur !== ch) cur.el.removeAttribute('id');
    cur = ch;
    if (ch) ch.el.id = 'chapter';
    layout();
    if (ch) goTo(ch, a && a.chapter === ch.index ? a.offset : 0);
    shown = -1;
    report();
  }

  let relayoutTimer = 0;
  function relayout() {
    clearTimeout(relayoutTimer);
    relayoutTimer = setTimeout(() => {
      if (busy()) { dirty = true; return; }
      rebuild(anchor());
    }, 60);
  }
  R.relayout = relayout;

  /// 停稳后补上排队的内容与重排
  function flush() {
    if (queued) {
      const q = queued;
      queued = null;
      dirty = false;
      apply(q[0], q[1]);
    } else if (dirty) {
      dirty = false;
      rebuild(anchor());
    }
  }

  // MARK: 页眉页脚与进度

  /// 屏幕上（过半即算）是哪一章的第几页：翻页模式是轨道页号，滚动模式是第几屏
  function where() {
    if (paged()) { const g = pageNow(); return { ch: locate(g), g: g }; }
    return { ch: cur, g: Math.floor(viewport.scrollTop / Math.max(1, viewport.clientHeight)) };
  }

  function context(ch, g) {
    const m = ch ? ch.meta : {};
    let pageNo = 1, pages = 1, fraction = 1;
    if (ch && paged()) {
      pages = ch.count;
      pageNo = clamp(g - ch.start + 1, 1, pages);
      fraction = pageNo / pages;
    } else if (ch) {
      const vh = Math.max(1, viewport.clientHeight);
      pages = Math.max(1, Math.ceil(viewport.scrollHeight / vh) - 1);
      pageNo = Math.min(pages, g + 1);
      fraction = viewport.scrollHeight > vh ? viewport.scrollTop / (viewport.scrollHeight - vh) : 1;
    }
    const total = Math.max(1, m.chapterCount || 1);
    const d = new Date();
    const pad = n => (n < 10 ? '0' : '') + n;
    return {
      book: m.book || '', author: m.author || '', chapter: m.title || '',
      chapterIndex: m.index || 0, chapterCount: total, page: pageNo, pages: pages,
      percent: Math.min(100, ((m.index || 0) + fraction) / total * 100),
      chapterProgress: Math.min(1, fraction),
      time: pad(d.getHours()) + ':' + pad(d.getMinutes()), battery: m.battery == null ? -1 : m.battery
    };
  }

  function fill(el, value) {
    const spans = el.children;
    const set = (i, t) => { spans[i].textContent = t == null ? '' : String(t); };
    if (value == null) value = {};
    if (typeof value !== 'object') value = { left: value };
    set(0, value.left); set(1, value.center); set(2, value.right);
  }

  const vars = {};
  function setVar(name, value) {
    if (vars[name] === value) return;
    vars[name] = value;
    page.style.setProperty(name, value);
  }

  function fillIfChanged(el, value) {
    const key = JSON.stringify(value);
    if (el.__key === key) return;
    el.__key = key;
    fill(el, value);
  }

  /// 页眉页脚、页面类名与 readerpage 事件。滑动途中过半就换（此时装饰正好淡到最弱），不等停稳
  function chrome() {
    const at = where();
    shown = at.g;
    shownCh = at.ch;
    const ctx = context(at.ch, at.g);
    R.ctx = ctx;
    const h = hook('header'), f = hook('footer');
    let head = h ? call(h, [ctx]) : null;
    let foot = f ? call(f, [ctx]) : null;
    if (head == null) head = { left: ctx.page === 1 ? ctx.book : ctx.chapter };
    if (foot == null) foot = { left: ctx.page + ' / ' + ctx.pages, right: ctx.percent.toFixed(1) + '%' };
    if (!at.ch || at.ch.meta.placeholder) { head = { left: ctx.book }; foot = {}; }
    fillIfChanged(headerEl, head);
    fillIfChanged(footerEl, foot);
    setVar('--progress', (ctx.percent / 100).toFixed(4));
    setVar('--chapter-progress', ctx.chapterProgress.toFixed(4));
    setVar('--battery', ctx.battery < 0 ? '1' : (ctx.battery / 100).toFixed(2));
    if (page.dataset.page !== String(ctx.page)) page.dataset.page = ctx.page;
    if (page.classList.contains('first-page') !== (ctx.page === 1)) page.classList.toggle('first-page', ctx.page === 1);
    if (page.classList.contains('last-page') !== (ctx.page === ctx.pages)) page.classList.toggle('last-page', ctx.page === ctx.pages);
    document.dispatchEvent(new CustomEvent('readerpage', { detail: ctx }));
    motion();
    scrubState();
  }

  /// 每帧只写一个变量 --page-pos（当前页在本章的位置：首页 0、末页 1），而且只写在页码条上：
  /// 自定义属性一变，它所在元素的整棵子树都要重算样式，写在整个装饰层上每帧要多花几倍时间。
  /// 没有页码条的主题只在页码变化时写到 #decor 上
  let posTarget = null, posValue = '';
  function setPos(value) {
    const v = value.toFixed(4);
    const el = scrubEl || decorEl;
    if (!el || (posValue === v && posTarget === el)) return;
    posValue = v;
    posTarget = el;
    el.style.setProperty('--page-pos', v);
  }
  function motion() {
    if (scrub) return;
    const ch = shownCh;
    let pos = 1;
    if (ch && ch.meta.placeholder) pos = 0;
    else if (ch && paged()) {
      const x = scrubEl ? viewport.scrollLeft / W : pageNow();
      pos = ch.count > 1 ? clamp((x - ch.start) / (ch.count - 1), 0, 1) : 1;
    } else if (ch) {
      const max = viewport.scrollHeight - viewport.clientHeight;
      pos = max > 0 ? clamp(viewport.scrollTop / max, 0, 1) : 1;
    }
    setPos(pos);
  }

  let motionFrame = 0;
  function follow() {
    motionFrame = 0;
    const at = where();
    if (at.g !== shown || at.ch !== shownCh) chrome();
    else if (scrubEl) motion();
  }

  // MARK: 页码条（装饰层里带 data-scrub 的元素）

  /// 拖动中：{ ch, n（本章页数）, p（指着第几页，从 0 起）, texts（每页开头的文字） }
  let scrub = null, scrubEl = null, scrubHit = null, scrubTip = null, ticksKey = '';

  /// 本章可以拖到的页数：翻页模式是本章页数，滚动模式按屏算
  function scrubPages(ch) {
    if (!ch || ch.meta.placeholder) return 1;
    if (paged()) return ch.count;
    const vh = Math.max(1, viewport.clientHeight), max = viewport.scrollHeight - vh;
    return max > 0 ? Math.ceil(max / vh) + 1 : 1;
  }

  function scrubIndex(ch) {
    if (!ch) return 0;
    if (paged()) return clamp(pageNow() - ch.start, 0, ch.count - 1);
    const vh = Math.max(1, viewport.clientHeight), max = viewport.scrollHeight - vh;
    return viewport.scrollTop >= max - 1 ? scrubPages(ch) - 1 : Math.floor(viewport.scrollTop / vh);
  }

  /// 每页开头的一小段文字：段落在多栏里每跨一栏有一个矩形，按矩形高度估算这一栏从第几个字开始
  function pageTexts(ch, n) {
    const out = new Array(n).fill('');
    if (!ch || ch.meta.placeholder) return out;
    const vr = viewport.getBoundingClientRect(), vh = Math.max(1, viewport.clientHeight);
    const at = r => paged()
      ? Math.floor((r.left - vr.left + viewport.scrollLeft - padL + 1) / W) - ch.start
      : Math.floor((r.top - vr.top + viewport.scrollTop) / vh);
    for (const el of blocks(ch)) {
      const rects = Array.from(el.getClientRects()).filter(r => r.height > 0);
      if (!rects.length) continue;
      const text = el.textContent.replace(/\s+/g, ' ');
      const sum = rects.reduce((s, r) => s + r.height, 0);
      let before = 0;
      for (const r of rects) {
        const p = at(r);
        if (p >= 0 && p < n && !out[p]) {
          const from = Math.floor(before / sum * text.length);
          const rest = text.slice(from).replace(/^[\s，。、；：！？,.;:!?”」』）)]+/, '').slice(0, 60);
          out[p] = from > 0 ? '…' + rest : rest;
        }
        before += r.height;
      }
    }
    for (let i = 1; i < n; i++) if (!out[i]) out[i] = out[i - 1];
    return out;
  }

  /// 刻度：每页一个 <i>，style 里的 --k 是位置（0…1）；已读过的带 .read，当前页带 .now。超过 80 页时隔几页画一个
  function paintTicks(ch) {
    const box = scrubEl && scrubEl.querySelector('[data-scrub-ticks]');
    if (!box) return;
    const n = scrubPages(ch), step = Math.max(1, Math.ceil(n / 80));
    const key = (ch ? ch.key : '') + '|' + n + '|' + paged();
    if (key !== ticksKey) {
      ticksKey = key;
      let html = '';
      for (let i = 0; i < n; i += step) html += '<i data-p="' + i + '" style="--k:' + (n > 1 ? i / (n - 1) : 0).toFixed(4) + '"></i>';
      box.innerHTML = html;
    }
    const now = scrub ? scrub.p : scrubIndex(ch);
    for (const t of box.children) {
      const p = +t.dataset.p;
      if (t.classList.contains('read') !== (p < now)) t.classList.toggle('read', p < now);
      if (t.classList.contains('now') !== (p === now)) t.classList.toggle('now', p === now);
    }
  }

  /// 透明的触摸区盖在页码条上（比它高一圈，好按），拖动不会带动正文
  function placeScrub() {
    if (!scrubEl) return;
    const r = scrubEl.getBoundingClientRect(), pr = page.getBoundingClientRect();
    const h = Math.max(44, r.height + 28);
    let top = r.top - pr.top + r.height / 2 - h / 2;
    const bottom = top + h;
    // iOS 上原生滚动区先于网页判断触摸：翻页模式让滚动区的底边停在触摸区上方，两者不重叠，拖页码条才不会变成翻页。
    // 触摸区最多往上伸到正文区底边，不挡正文
    if (paged() && r.top - pr.top >= pr.height - textBottom - 20) {
      top = Math.max(top, pr.height - textBottom);
      viewport.style.bottom = (pr.height - top) + 'px';
    }
    Object.assign(scrubHit.style, {
      left: (r.left - pr.left - 12) + 'px', width: (r.width + 24) + 'px', top: top + 'px', height: Math.max(24, bottom - top) + 'px'
    });
  }

  function scrubState() {
    if (!scrubEl) return;
    const off = !cfg.interactive || !shownCh || shownCh.meta.placeholder || scrubPages(shownCh) < 2;
    if (scrubHit.hidden !== off) scrubHit.hidden = off;
    paintTicks(shownCh);
  }

  function scrubMove(x) {
    const r = scrubEl.getBoundingClientRect();
    const f = clamp((x - r.left) / Math.max(1, r.width), 0, 1);
    const p = Math.round(f * (scrub.n - 1));
    setPos(f);
    scrubEl.style.setProperty('--scrub', f.toFixed(4));
    if (p === scrub.p) return;
    scrub.p = p;
    scrubTip.firstChild.textContent = (p + 1) + ' / ' + scrub.n;
    scrubTip.lastChild.textContent = scrub.texts[p] || '';
    const pr = page.getBoundingClientRect(), half = scrubTip.offsetWidth / 2;
    const cx = r.left - pr.left + (scrub.n > 1 ? p / (scrub.n - 1) : 0) * r.width;
    scrubTip.style.left = clamp(cx, half + 10, W - half - 10) + 'px';
    scrubTip.style.bottom = (pr.bottom - r.top + 14) + 'px';
    paintTicks(scrub.ch);
    post('tick');
    document.dispatchEvent(new CustomEvent('readerscrub', { detail: { active: true, page: p + 1, pages: scrub.n, fraction: f } }));
  }

  function scrubStart(e) {
    e.stopPropagation();
    e.preventDefault();
    const ch = shownCh;
    if (!ch || busy()) return;
    const n = scrubPages(ch);
    scrub = { ch: ch, n: n, p: -1, texts: pageTexts(ch, n) };
    page.classList.add('scrubbing');
    scrubMove(e.touches[0].clientX);
  }

  function scrubDrag(e) {
    e.stopPropagation();
    e.preventDefault();
    if (scrub) scrubMove(e.touches[0].clientX);
  }

  function scrubEnd(e) {
    e.stopPropagation();
    if (!scrub || e.touches.length) return;
    const s = scrub;
    scrub = null;
    page.classList.remove('scrubbing');
    document.dispatchEvent(new CustomEvent('readerscrub', { detail: { active: false, page: s.p + 1, pages: s.n, fraction: s.n > 1 ? s.p / (s.n - 1) : 0 } }));
    if (s.ch !== shownCh) return motion();
    if (paged()) scrollToPage(s.ch.start + s.p, false);
    else viewport.scrollTop = Math.min(viewport.scrollHeight - viewport.clientHeight, s.p * viewport.clientHeight);
    report();
  }

  function setupScrub() {
    scrubEl = decorEl.querySelector('[data-scrub]');
    if (!scrubEl) return;
    scrubHit = document.createElement('div');
    scrubHit.id = 'scrub-hit';
    scrubTip = document.createElement('div');
    scrubTip.id = 'scrub-tip';
    scrubTip.innerHTML = '<b></b><span></span>';
    page.appendChild(scrubHit);
    page.appendChild(scrubTip);
    scrubHit.addEventListener('touchstart', scrubStart, { passive: false });
    scrubHit.addEventListener('touchmove', scrubDrag, { passive: false });
    scrubHit.addEventListener('touchend', scrubEnd);
    scrubHit.addEventListener('touchcancel', scrubEnd);
  }


  function report() {
    if (quiet) return;
    chrome();
    if (!cur) return;
    clearTimeout(reportTimer);
    reportTimer = setTimeout(() => {
      if (!cur) return;
      const r = visibleRange(cur);
      post('position', { chapter: cur.index, start: r[0], end: r[1] });
    }, 30);
  }

  // MARK: 翻页

  /// 主题写了 `--page-turn: none` 时，平移点按不播滑动。仿真由阅读器设置决定，不看这个值
  const themeStill = () => getComputedStyle(page).getPropertyValue('--page-turn').trim() === 'none';

  function turn(forward) {
    if (!cur) return;
    if (!paged()) {
      viewport.scrollBy({ top: (forward ? 1 : -1) * viewport.clientHeight * 0.88, behavior: 'smooth' });
      return;
    }
    const target = pageNow() + (forward ? 1 : -1);
    if (target < 0 || target >= total) return post('edge', { dir: forward ? 'next' : 'prev' });
    if (cfg.turn === 'curl') return post('curl', { phase: 'tap', forward: !!forward, from: pageNow(), to: target });
    const instant = cfg.turn === 'none' || themeStill();
    scrollToPage(target, !instant);
    if (instant) report();
  }

  R.turn = turn;
  R.settle = () => { if (paged()) scrollToPage(pageNow(), true); };
  /// 截下一页时先把正文滚过去，截完再滚回来；quiet 挡住位置上报
  R.arm = function (on) { quiet = !!on; if (!on) report(); };
  R.hold = function (g) {
    quiet = true;
    curlPin = null;
    scrollToPage(g, false);
    chrome();
    requestAnimationFrame(function () { requestAnimationFrame(function () { post('held'); }); });
  };
  R.jump = function (g) {
    quiet = true;
    scrollToPage(g, false);
    chrome();
  };
  R.land = function (g) {
    quiet = true;
    scrollToPage(g, false);
    chrome();
    quiet = false;
    report();
  };

  function hasSelection() {
    const s = window.getSelection();
    return s && !s.isCollapsed && s.toString().length > 0;
  }

  /// 与原生一致：左三分之一上一页、右三分之一下一页、中间呼出菜单
  function tap(cx) {
    if (cfg.menu || !paged()) return post('menu');
    if (cx > W / 3 && cx < W * 2 / 3) return post('menu');
    turn(cfg.tapBoth || cx >= W * 2 / 3);
  }

  let touch = null;
  /// 仿真拖动：{ forward, from, to, progress, edge }
  let curl = null;
  /// 卷页手势进行中把正文钉在起始页，避免手指把横向滚动容器带走；截下一页前会放开
  let curlPin = null;
  function onStart(e) {
    touching = e.touches.length > 0;
    if (!cfg.interactive || e.touches.length > 1) { touch = null; return; }
    const t = e.touches[0];
    const el = e.target.nodeType === 1 ? e.target : e.target.parentElement;
    const scrubbing = !!(el && el.closest && el.closest('#scrub-hit, [data-scrub]'));
    touch = { x: t.clientX, y: t.clientY, dy: 0, t: Date.now(), left: viewport.scrollLeft, top: viewport.scrollTop,
              moved: false, selecting: hasSelection(), scrubbing: scrubbing };
  }
  function onMove(e) {
    if (!touch) return;
    const t = e.touches[0];
    const dx = t.clientX - touch.x;
    touch.dy = t.clientY - touch.y;
    if (Math.abs(dx) > 10 || Math.abs(touch.dy) > 10) touch.moved = true;
    if (cfg.turn !== 'curl' || !paged() || touch.scrubbing || touch.selecting || cfg.menu) return;
    if (!touch.dir && touch.moved) touch.dir = Math.abs(dx) > Math.abs(touch.dy) ? 'x' : 'y';
    if (touch.dir !== 'x') return;
    if (!curl && touch.moved) {
      // 按住一会儿再拖，多半是在选字，不要卷页
      if (hasSelection() || Date.now() - touch.t > 480) { touch.selecting = true; return; }
      const forward = dx < 0;
      const target = pageNow() + (forward ? 1 : -1);
      if (target < 0 || target >= total) curl = { edge: true, forward: forward, fire: false };
      else {
        curl = { edge: false, forward: forward, from: pageNow(), to: target, progress: 0 };
        curlPin = curl.from;
        post('curl', { phase: 'begin', forward: forward, from: curl.from, to: curl.to });
      }
    }
    if (curl && curl.edge) { curl.fire = Math.abs(dx) > Math.min(120, W * 0.28); return; }
    if (!curl || curl.edge) return;
    const span = Math.max(1, W);
    const next = Math.max(0, Math.min(1, curl.forward ? -dx / span : dx / span));
    if (curlPin != null) viewport.scrollLeft = curlPin * W;
    if (Math.abs(next - curl.progress) < 0.004) return;
    curl.progress = next;
    post('curl', { phase: 'move', progress: next });
  }
  function endCurl() {
    if (!curl) return;
    const drag = curl;
    curl = null;
    curlPin = null;
    if (drag.edge) { if (drag.fire) post('edge', { dir: drag.forward ? 'next' : 'prev' }); return; }
    post('curl', { phase: 'end', progress: drag.progress, forward: drag.forward, from: drag.from, to: drag.to });
  }
  function onEnd(e) {
    touching = e.touches.length > 0;
    const tt = touch;
    touch = null;
    if (curl) { endCurl(); return; }
    if (!busy()) flush();
    if (!tt) return;
    if (!paged() && cur && !cur.meta.placeholder) {
      const max = viewport.scrollHeight - viewport.clientHeight;
      if (tt.dy < -70 && tt.top >= max - 2 && cur.meta.hasNext) return post('edge', { dir: 'next' });
      if (tt.dy > 70 && tt.top <= 0 && cur.meta.hasPrev) return post('edge', { dir: 'prev' });
    }
    const scrolled = Math.abs(viewport.scrollLeft - tt.left) > 2 || Math.abs(viewport.scrollTop - tt.top) > 2;
    if (tt.moved || scrolled || Date.now() - tt.t > 380) return;
    if (tt.selecting || hasSelection()) { window.getSelection().removeAllRanges(); return; }
    const target = e.target;
    if (target.closest && target.closest('[data-comment]')) {
      return post('action', { paragraph: +target.closest('[data-comment]').dataset.comment });
    }
    if (target.closest && target.closest('[data-retry]')) return post('retry');
    if (target.closest && target.closest('a, button, input, [data-tap]')) return;
    // 装饰层在正文滚动区下面：按坐标找到可点的贴纸，替它派发 click
    const under = document.elementsFromPoint(tt.x, tt.y)
      .map(el => el.closest && el.closest('[data-tap]'))
      .find(el => el && !viewport.contains(el));
    if (under) {
      under.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: tt.x, clientY: tt.y }));
      return;
    }
    tap(tt.x);
  }

  function settled() {
    clearTimeout(scrollTimer);
    scrolling = false;
    if (touching) return;
    if (paged()) setCurrent(locate(pageNow()));
    flush();
    report();
  }

  /// 滑动途中只更新装饰层（每帧一次）；换章、上报位置、排队的重排都等停稳
  function onScroll() {
    scrolling = true;
    if (!motionFrame) motionFrame = requestAnimationFrame(follow);
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(settled, 100);
  }

  // MARK: 原生调用

  R.configure = function (c) {
    const a = anchor();
    cfg = Object.assign(cfg, c);
    const root = document.documentElement.style;
    Object.keys(cfg.vars || {}).forEach(k => root.setProperty(k, cfg.vars[k]));
    rebuild(a);
  };

  R.setMenu = v => { cfg.menu = v; };

  R.setFonts = css => { fontStyle.textContent = css; relayout(); };

  function classify(el) {
    const fn = hook('paragraphClass');
    if (!fn) return;
    el.querySelectorAll('p[data-i]').forEach(p => {
      const name = call(fn, [p.textContent, +p.dataset.i]);
      if (name) String(name).split(/\s+/).filter(Boolean).forEach(n => p.classList.add(n));
    });
  }

  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

  function render(ch, item) {
    const el = ch.el;
    el.className = 'chapter';
    el.dataset.chapter = ch.index;
    if (item.placeholder) {
      const p = item.placeholder;
      el.innerHTML = '<div class="placeholder"><b>' + esc(p.title) + '</b><span>' + esc(p.message) + '</span>'
        + (p.failed ? '<button data-retry>重试</button>' : '') + '</div>';
      return;
    }
    el.innerHTML = item.html + (ch.meta.hasNext ? '<div class="chap-end">上拉进入下一章</div>' : '');
    classify(el);
    const ready = hook('chapterReady');
    const m = ch.meta;
    if (ready) call(ready, [el, { index: m.index || 0, title: m.title || '', book: m.book || '', author: m.author || '', chapterCount: m.chapterCount || 1 }]);
    el.querySelectorAll('img').forEach(img => {
      img.decoding = 'async';
      if (!img.complete) img.addEventListener('load', relayout, { once: true });
    });
  }

  /// 换上新的章节窗口（上一章、本章、下一章）。未变的章原样保留，排版后回到原来看到的位置；
  /// `focus.force` 时（打开、目录跳转）改为定位到 focus 指定的偏移
  function apply(list, focus) {
    if (focus.force) pendingFocus = { chapter: focus.chapter, offset: focus.offset };
    let a = focus.force ? pendingFocus : (anchor() || { chapter: focus.chapter, offset: focus.offset });
    if (!focus.force && pendingFocus && cur && cur.index === pendingFocus.chapter) a = pendingFocus;
    const old = new Map(chapters.map(c => [c.index, c]));
    const next = [];
    list.forEach(item => {
      const index = item.meta.index;
      const prev = old.get(index);
      old.delete(index);
      if (prev && prev.key === item.key) {
        prev.meta = item.meta;
        next.push(prev);
        return;
      }
      const ch = { index: index, key: item.key, meta: item.meta, el: prev ? prev.el : document.createElement('article'),
                   start: 0, count: 1, fromEnd: prev ? prev.fromEnd : false };
      if (cur === prev) cur = ch;
      render(ch, item);
      next.push(ch);
    });
    old.forEach(c => { if (cur === c) cur = null; c.el.remove(); });
    chapters = next.sort((x, y) => x.index - y.index);
    chapters.forEach(c => { if (c.el.parentNode !== track) track.appendChild(c.el); });
    rebuild(a);
    const target = pendingFocus && chapters.find(c => c.index === pendingFocus.chapter);
    if (target && !target.meta.placeholder) pendingFocus = null;
    applySpeak();
  }

  R.setChapters = function (list, focus) {
    if (busy() && !focus.force) { queued = [list, focus]; return; }
    queued = null;
    apply(list, focus);
  };

  R.goPage = n => { if (cur) { scrollToPage(cur.start + n, false); report(); } };

  let spoken = null;
  function applySpeak() {
    if (!window.CSS || !CSS.highlights || typeof Highlight === 'undefined') return;
    CSS.highlights.delete('speak');
    const ch = spoken && chapters.find(c => c.index === spoken.chapter);
    if (!ch || ch.meta.placeholder) return;
    const a = point(ch, spoken.start), b = point(ch, spoken.end);
    if (!a || !b || a.img || b.img || a.el || b.el) return;
    const r = document.createRange();
    r.setStart(a.node, a.offset);
    r.setEnd(b.node, b.offset);
    CSS.highlights.set('speak', new Highlight(r));
  }
  R.speak = function (chapter, start, end) {
    spoken = chapter == null ? null : { chapter: chapter, start: start, end: end };
    applySpeak();
  };
  /// 朗读走到当前页之外时翻过去（下一页用动画）
  R.reveal = function (chapter, offset) {
    const ch = chapters.find(c => c.index === chapter);
    if (!ch || ch.meta.placeholder || busy()) return;
    if (!paged()) {
      if (ch !== cur) return;
      const v = viewport.getBoundingClientRect(), r = rectOf(ch, offset);
      if (r && (r.top < v.top || r.bottom > v.bottom)) viewport.scrollTo({ top: Math.max(0, pageOf(ch, offset) - 40), behavior: 'smooth' });
      return;
    }
    const target = ch.start + pageOf(ch, offset), g = pageNow();
    if (target === g) return;
    if (target === g + 1) scrollToPage(target, true);
    else { scrollToPage(target, false); report(); }
  };

  R.__boot = function () {
    page = $('page'); viewport = $('viewport'); track = $('track'); snaps = $('snaps');
    headerEl = $('header'); footerEl = $('footer'); fontStyle = $('font-faces'); decorEl = $('decor');
    document.addEventListener('touchstart', onStart, { passive: true });
    document.addEventListener('touchmove', onMove, { passive: true });
    document.addEventListener('touchend', onEnd, { passive: true });
    document.addEventListener('touchcancel', e => {
      touching = e.touches.length > 0;
      if (curl) endCurl();
      touch = null;
      if (!busy()) flush();
    });
    viewport.addEventListener('scroll', onScroll, { passive: true });
    viewport.addEventListener('scrollend', () => { if (scrolling) settled(); });
    window.addEventListener('resize', relayout);
    if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', relayout);
    if (document.fonts) document.fonts.addEventListener('loadingdone', relayout);
    document.querySelectorAll('#decor img').forEach(img => { img.decoding = 'async'; });
    setupScrub();
    setInterval(() => { if (!busy()) chrome(); }, 30000);
    measure();
    post('ready');
  };
})();